import createReactClass from  'create-react-class';

window.createReactClass=createReactClass;
//内部信息
export {default as ComponentMap} from './ComponentMap';
export {default as ABaseComponent} from './ABaseComponent';
//export {default as EChart} from './chart/echarts/EChart';

/**↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓基础构件↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓**/
/*按钮 [button]*/
export {default as Button} from './base/button/Button';
/*图标 [Icon]*/
export {default as Icon} from './base/icon/Icon';

/*分割线 [Divider]*/
export {default as Divider} from './base/divider/Divider';
/*布局 [Layout]*/
export * from './base/layout';
/*间距 [Space]*/
export {default as Space} from './base/space/Space';

/*固钉 [Affix]*/
export {default as Affix} from './base/affix/Affix';
/*面包屑 [Breadcrumb]*/
export {default as Breadcrumb} from './base/breadcrumb/Breadcrumb';
/*下拉菜单 [Dropdown]*/
export {default as Dropdown} from './base/dropdown/Dropdown';
/*菜单 [Menu]*/
export {default as Menu} from './base/menu/Menu';
/*分页 [Pagination]*/
export {default as Pagination} from './base/pagination/Pagination';
/*步骤条 [Steps]*/
export {default as Steps} from './base/steps/Steps';

/*表单 [form]*/
export {default as Form} from './base/form/Form';
/*表单域 [formFieldArea]*/
export {default as FormFieldArea} from './base/form/FormFieldArea';
/*隐藏域 [HiddenField]*/
export {default as HiddenField} from './base/form/HiddenField';
/*输入框 [input]*/
export {default as Input} from './base/input/Input';
/*密码框 [inputPassword]*/
export {default as InputPassword} from './base/input/InputPassword';
/*搜索框 [search]*/
export {default as Search} from './base/input/Search';
/*文本域 [TextArea]*/
export {default as TextArea} from './base/input/TextArea';
/*数字框 [inputNumber]*/
export {default as InputNumber} from './base/InputNumber/InputNumber';
/*级联选择 [Cascader]*/
export {default as Cascader} from './base/cascader/Cascader';
/*多选框 [Checkbox]*/
export {default as Checkbox} from './base/checkbox/CheckboxGroup';
/*提及框 [Mentions]*/
export {default as Mentions} from './base/mention/Mention';
/*单选框 [Radio]*/
export {default as RadioGroup} from './base/radio/RadioGroup';
/*评分 [rate]*/
export {default as Rate} from './base/rate/Rate';
/*选择框 [selet]*/
export {default as Select} from './base/select/Select';
/*滑动条 [Slider]*/
export {default as Slider} from './base/slider/Slider';
/*开关 [Switch]*/
export {default as Switch} from './base/switch/Switch';
/*日期框 [DatePicker]*/
export {default as DatePicker} from './base/datePicker/DatePicker';
/*时间选择框 [TimePicker]*/
export {default as TimePicker} from './base/timepicker/TimePicker';
/*树选择 [TimePicker]*/
export {default as TreeSelect} from './base/treeSelect/TreeSelect';
/*上传 [Upload]*/
export {default as Upload} from './base/upload/Upload';
/*浏览选择器 [BrowseSelect]*/
export {default as BrowseSelect} from './base/browseSelect/BrowseSelect';

/*弹窗[ Dialog]*/
export {default as  Dialog} from './base/dialog/Dialog';

/*抽屉[ Drawer]*/
export {default as  Drawer} from './base/drawer/Drawer';
export * from './base/chart/list';

/*头像 [Avatar]*/
export {default as Avatar} from './base/avatar/Avatar';
/*徽标数 [Badge]*/
export {default as Badge} from './base/badge/Badge';
/*日历 [Calendar]*/
export {default as Calendar} from './base/calendar/Calendar';
/*卡片 [Card]*/
export {default as Card} from './base/card/Card';
/*走马灯 [Carousel]*/
export {default as Carousel} from './base/carousel/Carousel';
/*折叠面板 [Collapse]*/
export {default as Collapse} from './base/collapse/Collapse';
/*折叠面板项 [CollapsePanel]*/
export {default as CollapsePanel} from './base/collapse/CollapsePanel';
/*描述列表 [Descriptions]*/
export {default as Descriptions} from './base/descriptions/Descriptions';
/*图片 [Image]*/
export {default as Image} from './base/image/Image';
/*列表 [List]*/
export {default as List} from './base/list/List';
/*数值统计 [Statistic]*/
export {default as Statistic} from './base/statistic/Statistic';
/*倒计时 [Countdown]*/
export {default as Countdown} from './base/statistic/Countdown';
/*表格 [Grid]*/
export {default as Grid} from './base/grid/Grid';
/*可编辑表格 [EditGrid]*/
export {default as EditGrid} from './base/grid/EditGrid';
/*表格列 [Column]*/
export {default as Column} from './base/grid/Column';
/*可编辑表格列 [EditColumn]*/
export {default as EditColumn} from './base/grid/EditColumn';
/*树 [Tree]*/
export {default as Tree} from './base/tree/Tree';
/*表格树 [GridTree]*/
export {default as GridTree} from './base/tree/GridTree';
/*标签页 [Tabs]*/
export {default as Tabs} from './base/tab/Tabs';
/*标签项 [TabPane]*/
export {default as TabPane} from './base/tab/TabPane';

/*锚点 [Anchor]*/
export {default as Anchor} from './base/anchor/Anchor';
/*回到顶部 [BackTop]*/
export {default as BackTop} from './base/backtop/BackTop';

/*带关闭按钮的确认框 [ConfirmWithCloseButton]*/
export {default as ConfirmWithCloseButton} from './base/confirm/ConfirmWithCloseButton';
/*div [Div]*/
export {default as Div} from './base/div/Div';
/*iframe [Iframe]*/
export {default as Iframe} from './base/iframe/Iframe';
/*iframe [Fieldset]*/
export {default as Fieldset} from './base/fieldset/Fieldset';
/*文本 [Span]*/
export {default as Span} from './base/span/Span';

export {default as MonthPicker} from './base/datePicker/MonthPicker';

export {default as YearPicker} from './base/datePicker/YearPicker';

export {default as RangePicker} from './base/datePicker/RangePicker';

export {default as Route} from "./base/route/Route"

//export {default as BraftEditor} from './base/BraftEditor/BraftEditor';