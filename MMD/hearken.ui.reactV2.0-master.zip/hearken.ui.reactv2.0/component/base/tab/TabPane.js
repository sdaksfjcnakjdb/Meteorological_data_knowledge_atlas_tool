import React,{Component} from 'react';
import ReactDOM from 'react-dom';
import {Tabs as AntdTabs} from 'antd';

const AntdTabPane=AntdTabs.TabPane;
export default AntdTabPane;

