import ABaseComponent from '../../ABaseComponent';
import { Drawer as AntdDrawer, Button as AntdButton } from 'antd';
import { PlusSquareTwoTone, CloseSquareTwoTone } from '@ant-design/icons'
import KGEditor from './KGEditor.js'


const data = {
    // 节点
    nodes: [
        {
            id: 'node1', // String，可选，节点的唯一标识
            x: 40,       // Number，必选，节点位置的 x 值
            y: 40,       // Number，必选，节点位置的 y 值
            width: 80,   // Number，可选，节点大小的 width 值
            height: 40,  // Number，可选，节点大小的 height 值
            label: 'hello', // String，节点标签
            shape: 'ellipse',
            
        },
        {
            id: 'node2', // String，节点的唯一标识
            x: 160,      // Number，必选，节点位置的 x 值
            y: 180,      // Number，必选，节点位置的 y 值
            width: 80,   // Number，可选，节点大小的 width 值
            height: 40,  // Number，可选，节点大小的 height 值
            label: 'world', // String，节点标签
            shape:"circle",
        },{
            id:"123",
            x: 40,
            y: 40,
            width: 100,
            height: 40,
            label: 'Source',
            shape:"circle",
            attrs: {
                body: {
                fill: '#f5f5f5',
                stroke: '#d9d9d9',
                strokeWidth: 1,
                magnet: true,
                connectionCount: 2, // 自定义属性，控制节点可连接多少条边
                },
            }
        },
    ],
    // 边
    edges: [
        {
            source: 'node1', // String，必须，起始节点 id
            target: 'node2', // String，必须，目标节点 id
        },
    ],
};




export default class Tool extends ABaseComponent {
    constructor(props) {
        super(props)
        this.state = {
            ...props,
            visible: false,
        }
        this.closeDrawer = this.closeDrawer.bind(this)
        this.openDrawer = this.openDrawer.bind(this)
    }



    componentDidMount() {
        super.componentDidMount();
    }


    

    openDrawer() {
        this.setState({ visible: true })
    }

    closeDrawer() {
        this.setState({ visible: false })
    }


    createContent() {
        return <div>
            <div><AntdButton>123213</AntdButton></div>
            <div>
               <KGEditor data={data}/>
                {/* {this.state.visible ? <CloseSquareTwoTone onClick={this.closeDrawer} style={{ position: "fixed", top: '50%', right: '265px', fontSize: '40px' }} />
                    : <PlusSquareTwoTone onClick={this.openDrawer} style={{ position: "fixed", top: '50%', right: '10px', fontSize: '40px' }} />} */}
            </div>
            <AntdDrawer mask={false} visible={this.state.visible} placement="right" closable={false}></AntdDrawer>
        </div>
    }
}

