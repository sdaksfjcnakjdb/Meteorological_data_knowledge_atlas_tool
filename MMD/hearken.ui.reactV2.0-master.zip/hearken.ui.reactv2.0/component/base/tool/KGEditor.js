import React from 'react';

import { Graph, Edge, EdgeView, Shape } from '@antv/x6'



export  default class  KGEditor extends React.Component {
    constructor(props){
        super(props);
        this.state={
            ...props
        }
    }

    componentDidMount() {
        this.init()
    }

    refContainer = (container) => {
        this.container = container
      }

    init() {
        const graph = new Graph({
            container: this.container,
            width: 800,
            height: 600,
            snapline:true,
            interacting: true,
            connecting:{
                allowNode:true,
                allowBlank:true,
            },
            background: {
                color: '#fffbe6', // 设置画布背景颜色
            },
            grid: {
                size: 10,      // 网格大小 10px
                visible: true, // 渲染网格背景
            },
        });
        let nodes = this.state.data.nodes.map(item=>{
            return {
                ...item,
            
                attrs: {
                    body: {
                      fill: '#f5f5f5',
                      stroke: '#d9d9d9',
                      strokeWidth: 1,
                      magnet: true,
                    },
                },
            }
        })
       
        graph.addNodes(nodes)
        graph.addNode({
            x: 60,
            y: 60,
            width: 160,
            height: 80,
            label: 'Rect With Ports',
            ports: [
              {
                id: 'port1',
                attrs: {
                  circle: {
                    r: 6,
                    magnet: true,
                    stroke: '#31d0c6',
                    strokeWidth: 2,
                    fill: '#fff',
                  },
                },
              },
              {
                id: 'port2',
                attrs: {
                  circle: {
                    r: 6,
                    magnet: true,
                    stroke: '#31d0c6',
                    strokeWidth: 2,
                    fill: '#fff',
                  },
                },
              },
              {
                id: 'port3',
                attrs: {
                  circle: {
                    r: 6,
                    magnet: true,
                    stroke: '#31d0c6',
                    strokeWidth: 2,
                    fill: '#fff',
                  },
                },
              },
            ],
          })
        graph.addEdges(this.state.data.edges)
        // this.setState({ graph: graph })
    }

    render(){
        return  <div id="container" ref={this.refContainer}></div>
    }
}