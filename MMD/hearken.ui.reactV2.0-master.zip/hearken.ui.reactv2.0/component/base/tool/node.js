
export default class EditorNode{
    constructor(node){
        this.node={
            ...node,
            
        }
    }
}