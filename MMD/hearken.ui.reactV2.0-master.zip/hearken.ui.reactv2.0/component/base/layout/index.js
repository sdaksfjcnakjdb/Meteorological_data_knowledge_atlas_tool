/*border布局 [Border]*/
export {default as Border} from './border/Border';
/*border布局-头部 [BorderHeader]*/
export {default as BorderHeader} from './border/BorderHeader';
/*border布局-内容 [BorderContent]*/
export {default as BorderContent} from './border/BorderContent';
/*border布局-左侧边栏 [BorderLeft]*/
export {default as BorderLeft} from './border/BorderLeft';
/*border布局-右侧边栏 [BorderRight]*/
export {default as BorderRight} from './border/BorderRight';
/*border布局-页脚 [BorderFooter]*/
export {default as BorderFooter} from './border/BorderFooter';
