import BorderHeader from './BorderHeader';

export default class BorderFooter extends BorderHeader{
	
}