import BorderLeft from './BorderLeft';

export default class BorderRight extends BorderLeft{
	
}